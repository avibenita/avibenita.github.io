Statistics Kingdom statistical icon extraction

Source: https://www.statskingdom.com/index.html
Extracted: September 30, 2026

Contents
  svg/             94 standalone SVG files, original vector shapes and gradients
  png/             94 transparent PNG files, each 512 pixels wide
  gallery.html     Searchable local preview; open in a web browser
  preview.png      Labelled contact sheet of all icons
  index.csv        Names, categories, filenames, and original page links
  manifest.json    Machine-readable inventory

The 89 source symbols and five additional statistical graphics are included.
The bulk-linear-regression symbol is defined on the page but has no visible row.
DeLong's independent and paired test rows use the same icon, exported once.
The site's brand logo, advertisements, and tracking images are excluded.

SVGs retain editable text with the original DM Sans font family and a sans-serif
fallback. The vector drawings and gradient stops are copied from the page.
PNG rendering uses an available sans-serif fallback where DM Sans is absent;
small text labels can therefore differ slightly from a browser with DM Sans.
All images retain their original aspect ratio and have transparent backgrounds.

Source attribution: Statistics Kingdom. This extraction includes no assertion
of ownership or a new licence for the original artwork.
